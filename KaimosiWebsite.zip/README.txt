KAIMOSI ELECTRICAL & PLUMBING SHOP WEBSITE

FILES
- index.html: website structure and content
- style.css: colours, layout and responsive design
- script.js: mobile menu, current year and email enquiry form

HOW TO PREVIEW
1. Extract the ZIP file.
2. Keep all three files in the same folder.
3. Double-click index.html to open the website in your browser.

CONTACT DETAILS INCLUDED
Phone / WhatsApp: 0740399536
Email: andronisemandela1@gmail.com
Location: Kaimosi Business Centre

PUBLISHING
You can upload these three files to GitHub Pages or another static website host.
The enquiry form opens the visitor's email app; it does not store messages on a server.
The website uses a Google Fonts stylesheet when internet access is available and has fallback fonts.
