const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');

menuToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
  menuToggle.textContent = isOpen ? '✕' : '☰';
});

mainNav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.textContent = '☰';
  });
});

document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('enquiryForm').addEventListener('submit', event => {
  event.preventDefault();
  const name = document.getElementById('customerName').value.trim();
  const message = document.getElementById('customerMessage').value.trim();
  if (!name || !message) return;

  const subject = encodeURIComponent('Product enquiry - Kaimosi Electrical and Plumbing Shop');
  const body = encodeURIComponent(`Hello Kaimosi Electrical and Plumbing Shop,\n\nMy name is ${name}.\n\n${message}\n\nThank you.`);
  window.location.href = `mailto:andronisemandela1@gmail.com?subject=${subject}&body=${body}`;
});
